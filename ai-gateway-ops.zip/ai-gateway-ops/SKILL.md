---
name: ai-gateway-ops
description: 通过调用 HTTP API 管理 AI Gateway 网关的操作技能，涵盖创建团队、创建或管理凭据、探测凭据上游模型、导入模型到团队、查看与修改模型能力、测试模型连通性、删除模型、创建跨团队个人工作区路由、配置与查看上游限额等全流程操作。当用户要求管理 AI 网关、配置模型凭据团队路由配额、探测上游模型、测试模型可用性、设置上游用量限额、跨团队共享模型或路由时使用。触发词包括创建团队、创建凭据、探测模型、导入模型、模型能力、测试模型、删除模型、个人路由、跨团队路由、上游限额、配额、gateway、凭据、虚拟模型。
agent_created: true
---

# AI Gateway Ops

## Overview

通过调用 AI Gateway 的 HTTP API 完成网关资源的全生命周期管理：团队 → 凭据 → 模型 → 路由 → 配额。所有操作基于已部署的 backend 服务（FastAPI），通过 Bearer JWT 认证，前缀为 `/ai-agent/api/v1/gateway`。

## 前置准备

### 1. 确认服务地址与认证

- **Base URL**：默认 `http://localhost:8000/ai-agent/api/v1`（可通过环境变量 `GATEWAY_BASE_URL` 覆盖；生产环境用实际域名）。
- **认证**：所有端点要求 HTTP Header `Authorization: Bearer <JWT>`。JWT 由登录端点签发；权限由平台 RBAC（`admin`/`user`/`viewer`）与团队 RBAC（`owner`/`admin`/`member`）共同决定。
- **团队上下文**：团队作用域端点（路径含 `{team_id}`）优先使用路径 team_id，其次读 `X-Team-Id` 头，最后回退到当前用户的 personal team。个人作用域端点（`/my-*`）无需传 team_id。

### 2. 使用封装客户端脚本

`scripts/gateway_client.py` 封装了所有操作的请求构造、认证注入与响应解析，避免反复手写 curl/requests 代码。优先使用它执行操作；需要定制时再读取并修改脚本。

运行方式（需先设置环境变量或通过参数传入 token）：

```bash
# 设置认证 token（从登录接口或现有会话获取）
export GATEWAY_BASE_URL="http://localhost:8000/ai-agent/api/v1"
export GATEWAY_TOKEN="<JWT>"

# 调用子命令
python scripts/gateway_client.py <command> [options]
# 例如：
python scripts/gateway_client.py teams create --name "我的团队"
python scripts/gateway_client.py credentials probe --team-id <tid> --credential-id <cid>
python scripts/gateway_client.py models test --team-id <tid> --model-id <mid>
```

未携带 token 时，脚本会报错并提示设置 `GATEWAY_TOKEN`。脚本支持 `--help` 查看每个子命令的参数。

## 任务分类

按需加载对应 references 文档以获取完整字段、状态码与示例。以下为各任务的端点速查与关键约束。

### 1. 团队管理 → `references/team_operations.md`

| 操作 | 方法 | 路径 |
|------|------|------|
| 创建团队 | `POST` | `/gateway/teams` |
| 列出团队 | `GET` | `/gateway/teams` |
| 更新团队 | `PATCH` | `/gateway/teams/{team_id}` |
| 删除团队 | `DELETE` | `/gateway/teams/{team_id}` |

- 创建团队恒为 `kind="shared"`，调用者自动成为 `owner`。
- personal team 由系统隐式创建，不可手动创建。
- 删除团队需 `owner` 权限，且不能删 personal team。

### 2. 凭据管理 → `references/credential_operations.md`

| 操作 | 方法 | 路径 |
|------|------|------|
| 创建团队/系统凭据 | `POST` | `/gateway/teams/{team_id}/credentials` |
| 创建个人 BYOK 凭据 | `POST` | `/gateway/my-credentials` |
| 列出凭据 | `GET` | `/gateway/teams/{team_id}/credentials` |
| 凭据详情 | `GET` | `/gateway/teams/{team_id}/credentials/{credential_id}` |
| 探测上游支持的模型 | `POST` | `/gateway/teams/{team_id}/credentials/{credential_id}/probe` |
| 探测个人凭据上游模型 | `POST` | `/gateway/my-credentials/{credential_id}/probe` |
| 更新凭据 | `PATCH` | `/gateway/teams/{team_id}/credentials/{credential_id}` |
| 删除凭据 | `DELETE` | `/gateway/teams/{team_id}/credentials/{credential_id}` |
| 查看上游 Profile | `GET` | `/gateway/provider-profiles` |

- `provider` 必须在允许列表内（团队/系统凭据：openai/anthropic/azure/bedrock/gemini/vertex_ai/dashscope/deepseek/volcengine/zhipuai/moonshot/cohere/mistral/fireworks/together_ai；个人 BYOK 子集见 references）。
- `api_key` 明文入参，服务端 Fernet 加密落库；响应只返回 `api_key_masked`，明文需调 `/reveal`。
- `scope=system` 需平台 admin；探测返回 `already_registered` 标记是否已导入。

### 3. 模型管理 → `references/model_operations.md`

| 操作 | 方法 | 路径 |
|------|------|------|
| 批量导入上游模型到团队 | `POST` | `/gateway/teams/{team_id}/credentials/{credential_id}/batch-import-models` |
| 手动注册单个团队模型 | `POST` | `/gateway/teams/{team_id}/models` |
| 列出团队模型 | `GET` | `/gateway/teams/{team_id}/models` |
| 模型详情 | `GET` | `/gateway/teams/{team_id}/models/{model_id}` |
| 修改模型（含能力位） | `PATCH` | `/gateway/teams/{team_id}/models/{model_id}` |
| 批量重算能力 | `POST` | `/gateway/teams/{team_id}/models/batch-resync-capabilities` |
| 测试模型连通性 | `POST` | `/gateway/teams/{team_id}/models/{model_id}/test` |
| 删除单个模型 | `DELETE` | `/gateway/teams/{team_id}/models/{model_id}` |
| 批量删除模型 | `POST` | `/gateway/teams/{team_id}/models/batch-delete` |
| 跨团队复制模型 | `POST` | `/gateway/models/copy-to-team` |
| 模型预设目录 | `GET` | `/gateway/teams/{team_id}/models/presets` |

- **模型能力**存储在 `GatewayModel.tags`（JSONB），通过 `PATCH` 的 `tags` 字段或 `model_types`/`resync_capabilities` 修改；无独立"能力"端点。能力位含 `supports_vision`/`supports_tools`/`supports_reasoning`/`thinking_param`/`temperature_policy` 等。
- 测试模型**成功与失败均返回 HTTP 200**，由响应 `success` 字段区分；同用户同模型每分钟限 1 次。
- 批量导入单次最多 50 项；批量删除单次最多 200 项。
- 个人模型对应端点在 `/gateway/my-models` 与 `/gateway/my-credentials/{id}/batch-import-models`。

### 4. 个人工作区路由（跨团队）→ `references/route_operations.md`

| 操作 | 方法 | 路径 |
|------|------|------|
| 列出个人路由 | `GET` | `/gateway/my-routes` |
| 创建个人路由 | `POST` | `/gateway/my-routes` |
| 更新个人路由 | `PATCH` | `/gateway/my-routes/{route_id}` |
| 删除个人路由 | `DELETE` | `/gateway/my-routes/{route_id}` |
| 列出可调用模型（跨团队） | `GET` | `/gateway/my-route-callable-models` |
| 团队路由管理 | `*` | `/gateway/teams/{team_id}/routes` |
| vkey 跨团队授权 | `POST` | `/gateway/teams/{team_id}/keys/{key_id}/grants` |

- 个人路由绑定到当前用户的 **personal team**，`primary_models` 用 `route_ref`（如 `slug/alias`）引用其他团队的模型实现跨团队。
- 通过 `GET /my-route-callable-models` 获取所有可引用模型的 `route_ref` 与 `prefix_dispatchable` 标记。
- 另一种跨团队共享方式：Virtual Key Grants，把 vkey 授权到其他团队。

### 5. 上游限额与配额 → `references/quota_operations.md`

| 操作 | 方法 | 路径 |
|------|------|------|
| 查看配额规则（含上游） | `GET` | `/gateway/teams/{team_id}/quota-rules?layer=upstream` |
| 批量 upsert 配额规则 | `PUT` | `/gateway/teams/{team_id}/quota-rules/batch` |
| 成员自助 upsert | `PUT` | `/gateway/teams/{team_id}/quota-rules/self-batch` |
| 启停配额 | `POST` | `/gateway/teams/{team_id}/quota-rules/enablement` |
| 调整用量 | `POST` | `/gateway/teams/{team_id}/quota-rules/usage-adjustments` |
| 删除配额 | `DELETE` | `/gateway/teams/{team_id}/quota-rules/plan` |
| 平台预算（旧式） | `*` | `/gateway/teams/{team_id}/budgets` |

- **上游限额** = `layer="upstream"` 的 QuotaRule，落 `provider_quotas` 表，核心字段 `credential_id` + `model_name`（NULL 表示整凭据共享）。
- **平台预算** = `layer="platform"`，落 `gateway_budgets` 表，按 `target_kind`（system/tenant/key/user）维度。
- **下游套餐** = `layer="downstream"`，绑定 vkey/apikey_grant。三者由 `quota-rules` 统一 facade 暴露。
- 上游限额 upsert 需团队 admin；成员仅能管理本人 BYOK 凭据的上游配额（self-batch）。

## 常见端到端工作流

### 工作流 A：从零搭建一个团队的模型调用能力

1. `POST /gateway/teams` 创建团队，记录 `team_id`。
2. `POST /gateway/teams/{team_id}/credentials` 创建凭据（传 `provider`/`name`/`api_key`），记录 `credential_id`。
3. `POST /gateway/teams/{team_id}/credentials/{credential_id}/probe` 探测上游可用模型，获取 `items[].upstream_model_id`。
4. `POST /gateway/teams/{team_id}/credentials/{credential_id}/batch-import-models` 批量导入选定模型。
5. `POST /gateway/teams/{team_id}/models/{model_id}/test` 测试连通性。
6. （可选）`PUT /gateway/teams/{team_id}/quota-rules/batch` 配置上游限额。
7. （可选）`POST /gateway/teams/{team_id}/routes` 创建团队虚拟路由。

### 工作流 B：跨团队共享模型（个人工作区聚合）

1. 在各团队完成模型注册（工作流 A）。
2. `GET /gateway/my-route-callable-models` 获取所有可引用模型的 `route_ref`。
3. `POST /gateway/my-routes` 创建个人路由，`primary_models` 填入跨团队的 `route_ref`（用 `slug/alias` 形式）。
4. （可选）`POST /gateway/teams/{team_id}/keys/{key_id}/grants` 把 vkey 授权给其他团队。

### 工作流 C：调整模型能力

1. `GET /gateway/teams/{team_id}/models/{model_id}` 查看当前 `tags` 与 `selector_capabilities`。
2. `PATCH /gateway/teams/{team_id}/models/{model_id}` 修改 `tags`（如 `{"supports_vision": true, "thinking_param": "none"}`），或传 `resync_capabilities: true` 从 LiteLLM 重算。

## 错误处理约定

- 业务错误返回统一 JSON：`{"error": {"code": "<CODE>", "message": "...", "details": {...}}}`，HTTP 状态码映射见 `docs/API_RESPONSE.md`。
- 常见 code：`UNAUTHORIZED`(401)、`FORBIDDEN`(403)、`NOT_FOUND`(404)、`VALIDATION_ERROR`(422)、`CONFLICT`(409)、`RATE_LIMITED`(429)。
- 探测/测试类操作的失败通常仍返回 200 并在响应体中给出 `message`/`reason`，需检查 `success`/`support` 字段。

## Resources

### scripts/
- `gateway_client.py` — 封装全部操作的 CLI 客户端。按子命令组织（`teams`/`credentials`/`models`/`routes`/`quotas`），自动注入 `Authorization` 头与 base URL，解析并格式化 JSON 响应。优先用它执行操作；定制需求可直接读取并修改脚本。

### references/
- `api_conventions.md` — 全局约定：路径前缀、认证、RBAC、团队上下文解析、响应格式、错误码。
- `team_operations.md` — 团队 CRUD 与成员管理完整字段。
- `credential_operations.md` — 凭据创建/探测/复制/可见性，含 provider 白名单与 profile 说明。
- `model_operations.md` — 模型导入/查看/能力修改/测试/删除/复制，含能力位清单。
- `route_operations.md` — 个人工作区路由与跨团队引用、vkey grants。
- `quota_operations.md` — 上游限额/平台预算/下游套餐统一 facade。

加载策略：执行某类任务前，先读取对应 references 文档以获取准确字段定义与示例；`api_conventions.md` 在首次使用或遇到认证/权限问题时必读。

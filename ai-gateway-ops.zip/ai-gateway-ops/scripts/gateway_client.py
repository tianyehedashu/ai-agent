#!/usr/bin/env python
"""AI Gateway Ops CLI 客户端。

封装 AI Gateway 的 HTTP API 调用，覆盖团队、凭据、模型、路由、配额全流程。
依赖标准库（urllib），无需安装第三方包。

环境变量:
  GATEWAY_BASE_URL  API 基地址，默认 http://localhost:8000/ai-agent/api/v1
  GATEWAY_TOKEN     Bearer JWT 认证 token（必需）

用法:
  python gateway_client.py <category> <command> [options]
  python gateway_client.py --help
  python gateway_client.py teams --help
  python gateway_client.py teams create --name "我的团队"

示例:
  export GATEWAY_BASE_URL="http://localhost:8000/ai-agent/api/v1"
  export GATEWAY_TOKEN="<JWT>"
  python gateway_client.py teams create --name "研发团队"
  python gateway_client.py credentials create --team-id <tid> --provider openai --name main --api-key sk-xxx
  python gateway_client.py credentials probe --team-id <tid> --credential-id <cid>
  python gateway_client.py models batch-import --team-id <tid> --credential-id <cid> --provider openai --items '[{"upstream_model_id":"gpt-4o"}]'
  python gateway_client.py models test --team-id <tid> --model-id <mid>
  python gateway_client.py quotas batch-upsert --team-id <tid> --rules '[{"layer":"upstream","credential_id":"<cid>","limit_usd":"50.00","period":"daily"}]'
"""

import argparse
import json
import os
import sys
import urllib.error
import urllib.request


DEFAULT_BASE_URL = "http://localhost:8000/ai-agent/api/v1"


class GatewayError(Exception):
    """Gateway API 错误。"""

    def __init__(self, status, code, message, details=None):
        self.status = status
        self.code = code
        self.message = message
        self.details = details or {}
        super().__init__(f"[{status}] {code}: {message}")


class ApiClient:
    """HTTP API 客户端。"""

    def __init__(self, base_url=None, token=None):
        self.base_url = (base_url or os.environ.get("GATEWAY_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        self.token = token or os.environ.get("GATEWAY_TOKEN")
        if not self.token:
            sys.stderr.write(
                "错误：未设置 GATEWAY_TOKEN 环境变量。\n"
                "请通过登录接口获取 JWT 后执行：export GATEWAY_TOKEN=\"<JWT>\"\n"
                "或使用 --token 参数传入。\n"
            )
            sys.exit(2)

    def _request(self, method, path, body=None, params=None):
        url = self.base_url + path
        if params:
            clean = {k: v for k, v in params.items() if v is not None}
            if clean:
                from urllib.parse import urlencode
                url = f"{url}?{urlencode(clean)}"

        data = None
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
        }
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"

        req = urllib.request.Request(url, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req) as resp:
                raw = resp.read().decode("utf-8")
                status = resp.status
        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8", errors="replace")
            try:
                err = json.loads(raw)
                err_body = err.get("error", err)
            except (ValueError, json.JSONDecodeError):
                err_body = {"code": "HTTP_ERROR", "message": raw or str(e)}
            raise GatewayError(e.code, err_body.get("code", "HTTP_ERROR"),
                               err_body.get("message", str(e)), err_body.get("details"))
        except urllib.error.URLError as e:
            raise GatewayError(0, "CONNECTION_ERROR", f"无法连接到 {url}: {e.reason}")

        if not raw:
            return None, status
        try:
            return json.loads(raw), status
        except json.JSONDecodeError:
            return raw, status

    # ---- 通用快捷方法 ----
    def get(self, path, params=None):
        return self._request("GET", path, params=params)[0]

    def post(self, path, body=None, params=None):
        return self._request("POST", path, body=body, params=params)[0]

    def put(self, path, body=None, params=None):
        return self._request("PUT", path, body=body, params=params)[0]

    def patch(self, path, body=None):
        return self._request("PATCH", path, body=body)[0]

    def delete(self, path, params=None):
        return self._request("DELETE", path, params=params)[0]


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------

def parse_json_arg(value, arg_name):
    """解析 JSON 字符串参数；若不是 JSON 则原样返回字符串。"""
    if value is None:
        return None
    try:
        return json.loads(value)
    except (ValueError, json.JSONDecodeError):
        return value


def print_json(data):
    """美化输出 JSON。"""
    if data is None:
        print("(无响应体)")
        return
    print(json.dumps(data, ensure_ascii=False, indent=2))


def add_common_opts(parser):
    parser.add_argument("--base-url", default=None, help="覆盖 GATEWAY_BASE_URL")
    parser.add_argument("--token", default=None, help="覆盖 GATEWAY_TOKEN")
    parser.add_argument("--raw", action="store_true", help="输出原始 JSON（不缩进）")


def make_client(args):
    client = ApiClient(base_url=args.base_url, token=args.token)
    return client


def run(handler):
    """包装命令处理函数，统一异常处理。"""
    def wrapper(args):
        try:
            result = handler(args)
            if result is not None:
                if getattr(args, "raw", False):
                    print(json.dumps(result, ensure_ascii=False))
                else:
                    print_json(result)
        except GatewayError as e:
            sys.stderr.write(f"API 错误: {e}\n")
            if e.details:
                sys.stderr.write(f"详情: {json.dumps(e.details, ensure_ascii=False)}\n")
            sys.exit(1)
    return wrapper


# ---------------------------------------------------------------------------
# teams 命令
# ---------------------------------------------------------------------------

def cmd_teams_create(args):
    client = make_client(args)
    body = {"name": args.name}
    if args.slug:
        body["slug"] = args.slug
    if args.settings:
        body["settings"] = parse_json_arg(args.settings, "settings")
    return client.post("/gateway/teams", body=body)


def cmd_teams_list(args):
    return make_client(args).get("/gateway/teams")


def cmd_teams_update(args):
    client = make_client(args)
    body = {}
    if args.name:
        body["name"] = args.name
    if args.slug:
        body["slug"] = args.slug
    if args.settings:
        body["settings"] = parse_json_arg(args.settings, "settings")
    if args.is_active is not None:
        body["is_active"] = args.is_active
    return client.patch(f"/gateway/teams/{args.team_id}", body=body)


def cmd_teams_delete(args):
    make_client(args).delete(f"/gateway/teams/{args.team_id}")
    return {"deleted": True, "team_id": args.team_id}


def cmd_teams_members_list(args):
    return make_client(args).get(f"/gateway/teams/{args.team_id}/members")


def cmd_teams_members_add(args):
    client = make_client(args)
    body = {"user_id": args.user_id, "role": args.role}
    return client.post(f"/gateway/teams/{args.team_id}/members", body=body)


# ---------------------------------------------------------------------------
# credentials 命令
# ---------------------------------------------------------------------------

def cmd_creds_create(args):
    client = make_client(args)
    body = {"provider": args.provider, "name": args.name, "api_key": args.api_key}
    if args.api_base:
        body["api_base"] = args.api_base
    if args.profile_id:
        body["profile_id"] = args.profile_id
    if args.scope:
        body["scope"] = args.scope
    if args.extra:
        body["extra"] = parse_json_arg(args.extra, "extra")
    return client.post(f"/gateway/teams/{args.team_id}/credentials", body=body)


def cmd_creds_create_personal(args):
    client = make_client(args)
    body = {"provider": args.provider, "name": args.name, "api_key": args.api_key}
    if args.api_base:
        body["api_base"] = args.api_base
    if args.profile_id:
        body["profile_id"] = args.profile_id
    if args.extra:
        body["extra"] = parse_json_arg(args.extra, "extra")
    return client.post("/gateway/my-credentials", body=body)


def cmd_creds_list(args):
    return make_client(args).get(f"/gateway/teams/{args.team_id}/credentials")


def cmd_creds_summaries(args):
    return make_client(args).get(f"/gateway/teams/{args.team_id}/credentials/summaries")


def cmd_creds_get(args):
    return make_client(args).get(f"/gateway/teams/{args.team_id}/credentials/{args.credential_id}")


def cmd_creds_reveal(args):
    return make_client(args).get(f"/gateway/teams/{args.team_id}/credentials/{args.credential_id}/reveal")


def cmd_creds_probe(args):
    return make_client(args).post(f"/gateway/teams/{args.team_id}/credentials/{args.credential_id}/probe")


def cmd_creds_probe_personal(args):
    return make_client(args).post(f"/gateway/my-credentials/{args.credential_id}/probe")


def cmd_creds_update(args):
    client = make_client(args)
    body = {}
    if args.name:
        body["name"] = args.name
    if args.api_key:
        body["api_key"] = args.api_key
    if args.api_base:
        body["api_base"] = args.api_base
    if args.is_active is not None:
        body["is_active"] = args.is_active
    if args.profile_id:
        body["profile_id"] = args.profile_id
    return client.patch(f"/gateway/teams/{args.team_id}/credentials/{args.credential_id}", body=body)


def cmd_creds_delete(args):
    make_client(args).delete(f"/gateway/teams/{args.team_id}/credentials/{args.credential_id}")
    return {"deleted": True, "credential_id": args.credential_id}


def cmd_creds_profiles(args):
    return make_client(args).get("/gateway/provider-profiles")


# ---------------------------------------------------------------------------
# models 命令
# ---------------------------------------------------------------------------

def cmd_models_batch_import(args):
    client = make_client(args)
    items = parse_json_arg(args.items, "items")
    body = {"provider": args.provider, "items": items}
    if args.capability:
        body["capability"] = args.capability
    if args.weight is not None:
        body["weight"] = args.weight
    if args.rpm_limit is not None:
        body["rpm_limit"] = args.rpm_limit
    if args.tpm_limit is not None:
        body["tpm_limit"] = args.tpm_limit
    if args.enabled is not None:
        body["enabled"] = args.enabled
    if args.tags:
        body["tags"] = parse_json_arg(args.tags, "tags")
    return client.post(f"/gateway/teams/{args.team_id}/credentials/{args.credential_id}/batch-import-models", body=body)


def cmd_models_create(args):
    client = make_client(args)
    body = {
        "name": args.name, "capability": args.capability,
        "real_model": args.real_model, "credential_id": args.credential_id,
        "provider": args.provider,
    }
    if args.weight is not None:
        body["weight"] = args.weight
    if args.tags:
        body["tags"] = parse_json_arg(args.tags, "tags")
    if args.display_name:
        body["display_name"] = args.display_name
    if args.upstream_call_shape:
        body["upstream_call_shape"] = args.upstream_call_shape
    if args.enabled is not None:
        body["enabled"] = args.enabled
    return client.post(f"/gateway/teams/{args.team_id}/models", body=body)


def cmd_models_list(args):
    client = make_client(args)
    params = {
        "page": args.page, "page_size": args.page_size, "q": args.q,
        "connectivity": args.connectivity, "sort": args.sort, "order": args.order,
        "provider": args.provider, "credential_id": args.credential_id,
        "type": args.type, "enabled": args.enabled, "registry_scope": args.registry_scope,
    }
    return client.get(f"/gateway/teams/{args.team_id}/models", params=params)


def cmd_models_get(args):
    client = make_client(args)
    params = {"registry_scope": args.registry_scope} if args.registry_scope else None
    return client.get(f"/gateway/teams/{args.team_id}/models/{args.model_id}", params=params)


def cmd_models_update(args):
    client = make_client(args)
    body = {}
    if args.name:
        body["name"] = args.name
    if args.real_model:
        body["real_model"] = args.real_model
    if args.credential_id:
        body["credential_id"] = args.credential_id
    if args.capability:
        body["capability"] = args.capability
    if args.model_types:
        body["model_types"] = parse_json_arg(args.model_types, "model_types")
    if args.tags:
        body["tags"] = parse_json_arg(args.tags, "tags")
    if args.display_name:
        body["display_name"] = args.display_name
    if args.resync_capabilities:
        body["resync_capabilities"] = True
    if args.enabled is not None:
        body["enabled"] = args.enabled
    if args.upstream_call_shape:
        body["upstream_call_shape"] = args.upstream_call_shape
    return client.patch(f"/gateway/teams/{args.team_id}/models/{args.model_id}", body=body)


def cmd_models_test(args):
    return make_client(args).post(f"/gateway/teams/{args.team_id}/models/{args.model_id}/test")


def cmd_models_delete(args):
    make_client(args).delete(f"/gateway/teams/{args.team_id}/models/{args.model_id}")
    return {"deleted": True, "model_id": args.model_id}


def cmd_models_batch_delete(args):
    client = make_client(args)
    model_ids = parse_json_arg(args.model_ids, "model_ids")
    return client.post(f"/gateway/teams/{args.team_id}/models/batch-delete", body={"model_ids": model_ids})


def cmd_models_copy_to_team(args):
    client = make_client(args)
    body = {
        "model_ids": parse_json_arg(args.model_ids, "model_ids"),
        "destination_team_id": args.destination_team_id,
        "credential_plans": parse_json_arg(args.credential_plans, "credential_plans"),
    }
    return client.post("/gateway/models/copy-to-team", body=body)


def cmd_models_resync(args):
    client = make_client(args)
    model_ids = parse_json_arg(args.model_ids, "model_ids")
    return client.post(f"/gateway/teams/{args.team_id}/models/batch-resync-capabilities",
                       body={"model_ids": model_ids})


def cmd_models_presets(args):
    return make_client(args).get(f"/gateway/teams/{args.team_id}/models/presets")


def cmd_models_callable(args):
    client = make_client(args)
    params = {"team_id": args.team_id} if args.team_id else None
    return client.get("/gateway/my-route-callable-models", params=params)


def cmd_models_my_list(args):
    return make_client(args).get("/gateway/my-models")


def cmd_models_my_test(args):
    return make_client(args).post(f"/gateway/my-models/{args.model_id}/test")


def cmd_models_my_delete(args):
    make_client(args).delete(f"/gateway/my-models/{args.model_id}")
    return {"deleted": True, "model_id": args.model_id}


# ---------------------------------------------------------------------------
# routes 命令
# ---------------------------------------------------------------------------

def cmd_routes_my_list(args):
    return make_client(args).get("/gateway/my-routes")


def cmd_routes_my_create(args):
    client = make_client(args)
    body = {
        "virtual_model": args.virtual_model,
        "primary_models": parse_json_arg(args.primary_models, "primary_models"),
    }
    if args.strategy:
        body["strategy"] = args.strategy
    if args.fallbacks_general:
        body["fallbacks_general"] = parse_json_arg(args.fallbacks_general, "fallbacks_general")
    if args.fallbacks_content_policy:
        body["fallbacks_content_policy"] = parse_json_arg(args.fallbacks_content_policy, "fallbacks_content_policy")
    if args.fallbacks_context_window:
        body["fallbacks_context_window"] = parse_json_arg(args.fallbacks_context_window, "fallbacks_context_window")
    if args.retry_policy:
        body["retry_policy"] = parse_json_arg(args.retry_policy, "retry_policy")
    return client.post("/gateway/my-routes", body=body)


def cmd_routes_my_update(args):
    client = make_client(args)
    body = {}
    if args.virtual_model:
        body["virtual_model"] = args.virtual_model
    if args.primary_models:
        body["primary_models"] = parse_json_arg(args.primary_models, "primary_models")
    if args.strategy:
        body["strategy"] = args.strategy
    if args.enabled is not None:
        body["enabled"] = args.enabled
    return client.patch(f"/gateway/my-routes/{args.route_id}", body=body)


def cmd_routes_my_delete(args):
    make_client(args).delete(f"/gateway/my-routes/{args.route_id}")
    return {"deleted": True, "route_id": args.route_id}


def cmd_routes_my_callable(args):
    client = make_client(args)
    params = {"team_id": args.team_id} if args.team_id else None
    return client.get("/gateway/my-route-callable-models", params=params)


def cmd_routes_team_list(args):
    return make_client(args).get(f"/gateway/teams/{args.team_id}/routes")


def cmd_routes_team_create(args):
    client = make_client(args)
    body = {
        "virtual_model": args.virtual_model,
        "primary_models": parse_json_arg(args.primary_models, "primary_models"),
    }
    if args.strategy:
        body["strategy"] = args.strategy
    return client.post(f"/gateway/teams/{args.team_id}/routes", body=body)


def cmd_routes_team_delete(args):
    make_client(args).delete(f"/gateway/teams/{args.team_id}/routes/{args.route_id}")
    return {"deleted": True, "route_id": args.route_id}


def cmd_grants_list(args):
    return make_client(args).get(f"/gateway/teams/{args.team_id}/keys/{args.key_id}/grants")


def cmd_grants_create(args):
    client = make_client(args)
    body = {"tenant_ids": parse_json_arg(args.tenant_ids, "tenant_ids")}
    return client.post(f"/gateway/teams/{args.team_id}/keys/{args.key_id}/grants", body=body)


def cmd_grants_grantable(args):
    return make_client(args).get(f"/gateway/teams/{args.team_id}/keys/{args.key_id}/grants/grantable-teams")


# ---------------------------------------------------------------------------
# quotas 命令
# ---------------------------------------------------------------------------

def cmd_quotas_list(args):
    client = make_client(args)
    params = {
        "layer": args.layer, "user_id": args.user_id,
        "credential_id": args.credential_id, "model_name": args.model_name,
        "period": args.period, "include_usage": args.include_usage,
        "page": args.page, "page_size": args.page_size,
    }
    return client.get(f"/gateway/teams/{args.team_id}/quota-rules", params=params)


def cmd_quotas_batch_upsert(args):
    client = make_client(args)
    rules = parse_json_arg(args.rules, "rules")
    return client.put(f"/gateway/teams/{args.team_id}/quota-rules/batch", body={"rules": rules})


def cmd_quotas_self_batch(args):
    client = make_client(args)
    rules = parse_json_arg(args.rules, "rules")
    return client.put(f"/gateway/teams/{args.team_id}/quota-rules/self-batch", body={"rules": rules})


def cmd_quotas_enablement(args):
    client = make_client(args)
    body = {
        "layer": args.layer, "budget_id": args.budget_id,
        "plan_id": args.plan_id, "quota_id": args.quota_id, "enabled": args.enabled,
    }
    return client.post(f"/gateway/teams/{args.team_id}/quota-rules/enablement", body=body)


def cmd_quotas_usage_adjustment(args):
    client = make_client(args)
    body = {
        "layer": args.layer, "budget_id": args.budget_id,
        "plan_id": args.plan_id, "quota_id": args.quota_id, "mode": args.mode,
    }
    if args.current_usd is not None:
        body["current_usd"] = args.current_usd
    if args.current_tokens is not None:
        body["current_tokens"] = args.current_tokens
    if args.current_requests is not None:
        body["current_requests"] = args.current_requests
    return client.post(f"/gateway/teams/{args.team_id}/quota-rules/usage-adjustments", body=body)


def cmd_quotas_delete(args):
    client = make_client(args)
    params = {"layer": args.layer, "quota_id": args.quota_id, "plan_id": args.plan_id}
    client.delete(f"/gateway/teams/{args.team_id}/quota-rules/plan", params=params)
    return {"deleted": True, "layer": args.layer, "quota_id": args.quota_id}


def cmd_budgets_list(args):
    client = make_client(args)
    params = {"target_kind": args.target_kind, "model_name": args.model_name}
    return client.get(f"/gateway/teams/{args.team_id}/budgets", params=params)


# ---------------------------------------------------------------------------
# 参数解析构建
# ---------------------------------------------------------------------------

def build_parser():
    parser = argparse.ArgumentParser(
        prog="gateway_client",
        description="AI Gateway Ops CLI - 管理团队/凭据/模型/路由/配额",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    add_common_opts(parser)
    sub = parser.add_subparsers(dest="category", required=True, metavar="<category>")

    _build_teams(sub)
    _build_credentials(sub)
    _build_models(sub)
    _build_routes(sub)
    _build_quotas(sub)
    return parser


def _build_teams(sub):
    p = sub.add_parser("teams", help="团队管理")
    sp = p.add_subparsers(dest="command", required=True, metavar="<command>")

    c = sp.add_parser("create", help="创建团队")
    c.add_argument("--name", required=True, help="团队名称")
    c.add_argument("--slug", help="URL slug（缺省自动生成）")
    c.add_argument("--settings", help="团队设置 JSON")
    c.set_defaults(func=run(cmd_teams_create))

    c = sp.add_parser("list", help="列出可见团队")
    c.set_defaults(func=run(cmd_teams_list))

    c = sp.add_parser("update", help="更新团队")
    c.add_argument("--team-id", required=True)
    c.add_argument("--name")
    c.add_argument("--slug")
    c.add_argument("--settings", help="设置 JSON")
    c.add_argument("--is-active", type=lambda x: x.lower() == "true", default=None)
    c.set_defaults(func=run(cmd_teams_update))

    c = sp.add_parser("delete", help="删除团队")
    c.add_argument("--team-id", required=True)
    c.set_defaults(func=run(cmd_teams_delete))

    m = sp.add_parser("members", help="成员管理")
    msp = m.add_subparsers(dest="mcommand", required=True, metavar="<command>")
    c = msp.add_parser("list", help="列出成员")
    c.add_argument("--team-id", required=True)
    c.set_defaults(func=run(cmd_teams_members_list))
    c = msp.add_parser("add", help="添加成员")
    c.add_argument("--team-id", required=True)
    c.add_argument("--user-id", required=True)
    c.add_argument("--role", default="member", help="owner/admin/member")
    c.set_defaults(func=run(cmd_teams_members_add))


def _build_credentials(sub):
    p = sub.add_parser("credentials", help="凭据管理")
    sp = p.add_subparsers(dest="command", required=True, metavar="<command>")

    c = sp.add_parser("create", help="创建团队/系统凭据")
    c.add_argument("--team-id", required=True)
    c.add_argument("--provider", required=True, help="提供商（openai/anthropic/...）")
    c.add_argument("--name", required=True, help="展示名")
    c.add_argument("--api-key", required=True, help="明文 API Key")
    c.add_argument("--api-base", help="OpenAI-compat base URL")
    c.add_argument("--profile-id", help="上游方案 ID")
    c.add_argument("--scope", choices=["team", "system"], default="team", help="写入目标（system 需平台 admin）")
    c.add_argument("--extra", help="扩展字段 JSON")
    c.set_defaults(func=run(cmd_creds_create))

    c = sp.add_parser("create-personal", help="创建个人 BYOK 凭据")
    c.add_argument("--provider", required=True)
    c.add_argument("--name", required=True)
    c.add_argument("--api-key", required=True)
    c.add_argument("--api-base")
    c.add_argument("--profile-id")
    c.add_argument("--extra", help="扩展字段 JSON")
    c.set_defaults(func=run(cmd_creds_create_personal))

    c = sp.add_parser("list", help="列出团队凭据")
    c.add_argument("--team-id", required=True)
    c.set_defaults(func=run(cmd_creds_list))

    c = sp.add_parser("summaries", help="凭据摘要列表")
    c.add_argument("--team-id", required=True)
    c.set_defaults(func=run(cmd_creds_summaries))

    c = sp.add_parser("get", help="凭据详情")
    c.add_argument("--team-id", required=True)
    c.add_argument("--credential-id", required=True)
    c.set_defaults(func=run(cmd_creds_get))

    c = sp.add_parser("reveal", help="解密返回明文 API Key")
    c.add_argument("--team-id", required=True)
    c.add_argument("--credential-id", required=True)
    c.set_defaults(func=run(cmd_creds_reveal))

    c = sp.add_parser("probe", help="探测凭据上游支持的模型")
    c.add_argument("--team-id", required=True)
    c.add_argument("--credential-id", required=True)
    c.set_defaults(func=run(cmd_creds_probe))

    c = sp.add_parser("probe-personal", help="探测个人凭据上游模型")
    c.add_argument("--credential-id", required=True)
    c.set_defaults(func=run(cmd_creds_probe_personal))

    c = sp.add_parser("update", help="更新凭据")
    c.add_argument("--team-id", required=True)
    c.add_argument("--credential-id", required=True)
    c.add_argument("--name")
    c.add_argument("--api-key")
    c.add_argument("--api-base")
    c.add_argument("--profile-id")
    c.add_argument("--is-active", type=lambda x: x.lower() == "true", default=None)
    c.set_defaults(func=run(cmd_creds_update))

    c = sp.add_parser("delete", help="删除凭据")
    c.add_argument("--team-id", required=True)
    c.add_argument("--credential-id", required=True)
    c.set_defaults(func=run(cmd_creds_delete))

    c = sp.add_parser("profiles", help="查看上游 Profile SSOT")
    c.set_defaults(func=run(cmd_creds_profiles))


def _build_models(sub):
    p = sub.add_parser("models", help="模型管理")
    sp = p.add_subparsers(dest="command", required=True, metavar="<command>")

    c = sp.add_parser("batch-import", help="批量导入上游模型到团队")
    c.add_argument("--team-id", required=True)
    c.add_argument("--credential-id", required=True)
    c.add_argument("--provider", required=True)
    c.add_argument("--items", required=True, help='JSON 数组，如 [{"upstream_model_id":"gpt-4o"}]')
    c.add_argument("--capability", default="chat", help="主调用面")
    c.add_argument("--weight", type=int)
    c.add_argument("--rpm-limit", type=int)
    c.add_argument("--tpm-limit", type=int)
    c.add_argument("--enabled", type=lambda x: x.lower() == "true", default=None)
    c.add_argument("--tags", help="标签 JSON")
    c.set_defaults(func=run(cmd_models_batch_import))

    c = sp.add_parser("create", help="手动注册单个团队模型")
    c.add_argument("--team-id", required=True)
    c.add_argument("--name", required=True, help="虚拟模型别名")
    c.add_argument("--capability", required=True, help="主调用面")
    c.add_argument("--real-model", required=True, help="真实模型 ID")
    c.add_argument("--credential-id", required=True)
    c.add_argument("--provider", required=True)
    c.add_argument("--weight", type=int)
    c.add_argument("--tags", help="标签 JSON（能力位）")
    c.add_argument("--display-name")
    c.add_argument("--upstream-call-shape", choices=["openai_compat", "anthropic_native"])
    c.add_argument("--enabled", type=lambda x: x.lower() == "true", default=None)
    c.set_defaults(func=run(cmd_models_create))

    c = sp.add_parser("list", help="列出团队模型")
    c.add_argument("--team-id", required=True)
    c.add_argument("--page", type=int)
    c.add_argument("--page-size", type=int)
    c.add_argument("--q", help="模糊搜索")
    c.add_argument("--connectivity", choices=["all", "success", "failed", "unknown"])
    c.add_argument("--sort", choices=["name", "created_at", "provider", "last_tested_at"])
    c.add_argument("--order", choices=["asc", "desc"])
    c.add_argument("--provider")
    c.add_argument("--credential-id")
    c.add_argument("--type", help="能力筛选")
    c.add_argument("--enabled", type=lambda x: x.lower() == "true", default=None)
    c.add_argument("--registry-scope", choices=["team", "system", "callable", "requestable", "system_requestable"])
    c.set_defaults(func=run(cmd_models_list))

    c = sp.add_parser("get", help="模型详情")
    c.add_argument("--team-id", required=True)
    c.add_argument("--model-id", required=True)
    c.add_argument("--registry-scope", choices=["team", "system", "callable", "requestable", "system_requestable"])
    c.set_defaults(func=run(cmd_models_get))

    c = sp.add_parser("update", help="修改模型（含能力位）")
    c.add_argument("--team-id", required=True)
    c.add_argument("--model-id", required=True)
    c.add_argument("--name")
    c.add_argument("--real-model")
    c.add_argument("--credential-id")
    c.add_argument("--capability")
    c.add_argument("--model-types", help='JSON 数组，如 ["text","image"]')
    c.add_argument("--tags", help='标签 JSON，如 {"supports_vision":true}')
    c.add_argument("--display-name")
    c.add_argument("--resync-capabilities", action="store_true", help="从 LiteLLM 重算能力")
    c.add_argument("--enabled", type=lambda x: x.lower() == "true", default=None)
    c.add_argument("--upstream-call-shape", choices=["openai_compat", "anthropic_native"])
    c.set_defaults(func=run(cmd_models_update))

    c = sp.add_parser("test", help="测试模型连通性")
    c.add_argument("--team-id", required=True)
    c.add_argument("--model-id", required=True)
    c.set_defaults(func=run(cmd_models_test))

    c = sp.add_parser("delete", help="删除单个模型")
    c.add_argument("--team-id", required=True)
    c.add_argument("--model-id", required=True)
    c.set_defaults(func=run(cmd_models_delete))

    c = sp.add_parser("batch-delete", help="批量删除模型")
    c.add_argument("--team-id", required=True)
    c.add_argument("--model-ids", required=True, help='JSON 数组，如 ["uuid1","uuid2"]')
    c.set_defaults(func=run(cmd_models_batch_delete))

    c = sp.add_parser("copy-to-team", help="跨团队复制模型")
    c.add_argument("--model-ids", required=True, help="JSON 数组")
    c.add_argument("--destination-team-id", required=True)
    c.add_argument("--credential-plans", required=True, help='JSON 数组，如 [{"source_credential_id":"...","mode":"existing","destination_credential_id":"..."}]')
    c.set_defaults(func=run(cmd_models_copy_to_team))

    c = sp.add_parser("resync", help="批量重算模型能力")
    c.add_argument("--team-id", required=True)
    c.add_argument("--model-ids", required=True, help="JSON 数组")
    c.set_defaults(func=run(cmd_models_resync))

    c = sp.add_parser("presets", help="模型预设目录")
    c.add_argument("--team-id", required=True)
    c.set_defaults(func=run(cmd_models_presets))

    c = sp.add_parser("callable-models", help="列出个人可调用模型（跨团队，用于路由引用）")
    c.add_argument("--team-id", help="按归属团队过滤")
    c.set_defaults(func=run(cmd_models_callable))

    c = sp.add_parser("my-list", help="列出个人模型")
    c.set_defaults(func=run(cmd_models_my_list))

    c = sp.add_parser("my-test", help="测试个人模型")
    c.add_argument("--model-id", required=True)
    c.set_defaults(func=run(cmd_models_my_test))

    c = sp.add_parser("my-delete", help="删除个人模型")
    c.add_argument("--model-id", required=True)
    c.set_defaults(func=run(cmd_models_my_delete))


def _build_routes(sub):
    p = sub.add_parser("routes", help="路由管理（个人工作区与团队）")
    sp = p.add_subparsers(dest="command", required=True, metavar="<command>")

    c = sp.add_parser("my-list", help="列出个人路由")
    c.set_defaults(func=run(cmd_routes_my_list))

    c = sp.add_parser("my-create", help="创建个人路由（可跨团队引用）")
    c.add_argument("--virtual-model", required=True, help="虚拟模型名")
    c.add_argument("--primary-models", required=True, help='JSON 数组，如 ["rd-team/gpt-4o","alias"]')
    c.add_argument("--strategy", help="调度策略")
    c.add_argument("--fallbacks-general", help="JSON 数组")
    c.add_argument("--fallbacks-content-policy", help="JSON 数组")
    c.add_argument("--fallbacks-context-window", help="JSON 数组")
    c.add_argument("--retry-policy", help="JSON 对象")
    c.set_defaults(func=run(cmd_routes_my_create))

    c = sp.add_parser("my-update", help="更新个人路由")
    c.add_argument("--route-id", required=True)
    c.add_argument("--virtual-model")
    c.add_argument("--primary-models", help="JSON 数组")
    c.add_argument("--strategy")
    c.add_argument("--enabled", type=lambda x: x.lower() == "true", default=None)
    c.set_defaults(func=run(cmd_routes_my_update))

    c = sp.add_parser("my-delete", help="删除个人路由")
    c.add_argument("--route-id", required=True)
    c.set_defaults(func=run(cmd_routes_my_delete))

    c = sp.add_parser("my-callable-models", help="列出可引用模型（含 route_ref）")
    c.add_argument("--team-id", help="按归属团队过滤")
    c.set_defaults(func=run(cmd_routes_my_callable))

    c = sp.add_parser("team-list", help="列出团队路由")
    c.add_argument("--team-id", required=True)
    c.set_defaults(func=run(cmd_routes_team_list))

    c = sp.add_parser("team-create", help="创建团队路由")
    c.add_argument("--team-id", required=True)
    c.add_argument("--virtual-model", required=True)
    c.add_argument("--primary-models", required=True, help="JSON 数组")
    c.add_argument("--strategy")
    c.set_defaults(func=run(cmd_routes_team_create))

    c = sp.add_parser("team-delete", help="删除团队路由")
    c.add_argument("--team-id", required=True)
    c.add_argument("--route-id", required=True)
    c.set_defaults(func=run(cmd_routes_team_delete))

    # vkey grants（跨团队授权）
    g = sp.add_parser("grants-list", help="列出 vkey 跨团队授权")
    g.add_argument("--team-id", required=True)
    g.add_argument("--key-id", required=True)
    g.set_defaults(func=run(cmd_grants_list))

    g = sp.add_parser("grants-create", help="授权 vkey 到其他团队")
    g.add_argument("--team-id", required=True)
    g.add_argument("--key-id", required=True)
    g.add_argument("--tenant-ids", required=True, help='JSON 数组，如 ["team-uuid-1"]')
    g.set_defaults(func=run(cmd_grants_create))

    g = sp.add_parser("grants-grantable", help="列出可授权团队")
    g.add_argument("--team-id", required=True)
    g.add_argument("--key-id", required=True)
    g.set_defaults(func=run(cmd_grants_grantable))


def _build_quotas(sub):
    p = sub.add_parser("quotas", help="配额与限额管理")
    sp = p.add_subparsers(dest="command", required=True, metavar="<command>")

    c = sp.add_parser("list", help="查看配额规则（layer=upstream 查上游限额）")
    c.add_argument("--team-id", required=True)
    c.add_argument("--layer", choices=["platform", "upstream", "downstream"])
    c.add_argument("--user-id")
    c.add_argument("--credential-id", help="按凭据过滤（上游限额常用）")
    c.add_argument("--model-name")
    c.add_argument("--period", choices=["daily", "monthly", "total"])
    c.add_argument("--include-usage", type=lambda x: x.lower() == "true", default=None)
    c.add_argument("--page", type=int)
    c.add_argument("--page-size", type=int)
    c.set_defaults(func=run(cmd_quotas_list))

    c = sp.add_parser("batch-upsert", help="批量 upsert 配额规则（含上游限额）")
    c.add_argument("--team-id", required=True)
    c.add_argument("--rules", required=True, help='JSON 数组，如 [{"layer":"upstream","credential_id":"...","limit_usd":"50.00","period":"daily"}]')
    c.set_defaults(func=run(cmd_quotas_batch_upsert))

    c = sp.add_parser("self-batch", help="成员自助 upsert（仅本人凭据）")
    c.add_argument("--team-id", required=True)
    c.add_argument("--rules", required=True, help="JSON 数组")
    c.set_defaults(func=run(cmd_quotas_self_batch))

    c = sp.add_parser("enablement", help="启停单条配额")
    c.add_argument("--team-id", required=True)
    c.add_argument("--layer", required=True, choices=["platform", "upstream", "downstream"])
    c.add_argument("--budget-id")
    c.add_argument("--plan-id")
    c.add_argument("--quota-id")
    c.add_argument("--enabled", type=lambda x: x.lower() == "true", required=True)
    c.set_defaults(func=run(cmd_quotas_enablement))

    c = sp.add_parser("usage-adjustment", help="手工调整用量/清零窗口")
    c.add_argument("--team-id", required=True)
    c.add_argument("--layer", required=True, choices=["platform", "upstream", "downstream"])
    c.add_argument("--budget-id")
    c.add_argument("--plan-id")
    c.add_argument("--quota-id")
    c.add_argument("--mode", required=True, choices=["set", "reset_window"])
    c.add_argument("--current-usd")
    c.add_argument("--current-tokens", type=int)
    c.add_argument("--current-requests", type=int)
    c.set_defaults(func=run(cmd_quotas_usage_adjustment))

    c = sp.add_parser("delete", help="删除上游/下游配额")
    c.add_argument("--team-id", required=True)
    c.add_argument("--layer", required=True, choices=["upstream", "downstream"])
    c.add_argument("--quota-id", required=True)
    c.add_argument("--plan-id", required=True)
    c.set_defaults(func=run(cmd_quotas_delete))

    c = sp.add_parser("budgets-list", help="列出平台预算（旧式）")
    c.add_argument("--team-id", required=True)
    c.add_argument("--target-kind", choices=["system", "tenant", "key", "user"])
    c.add_argument("--model-name")
    c.set_defaults(func=run(cmd_budgets_list))


def main():
    parser = build_parser()
    args = parser.parse_args()
    if not hasattr(args, "func"):
        parser.print_help()
        sys.exit(2)
    args.func(args)


if __name__ == "__main__":
    main()
